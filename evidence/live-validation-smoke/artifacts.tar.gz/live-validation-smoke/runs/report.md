# Controlled live validation

**Descriptive engineering evidence; not a primary research result.**

Logical metrics start at the first receiver callback per event, including rejected attempts. Publisher ACKs acknowledge transport; subscriber receipts are reconciled separately. Policies share the planned trace, while realized callback timings differ. No warm-up is removed and no statistical superiority is inferred.

| Scenario | Seed | Policy | Generated | Completed | Dropped |
| --- | --- | --- | --- | --- | --- |
| s000 | 6101 | fixed_guarded | 40 | 24 | 16 |
| s000 | 6101 | edf | 40 | 24 | 16 |
| s000 | 6101 | aging | 40 | 24 | 16 |
| s000 | 6101 | adaptive_guarded | 40 | 24 | 16 |
| s000 | 6101 | adaptive | 40 | 24 | 16 |
| s000 | 6101 | priority | 40 | 24 | 16 |
| s000 | 6101 | fifo | 40 | 24 | 16 |
| s000 | 6101 | fixed_deadline | 40 | 24 | 16 |

Functional checks: overload_priority, overload_adaptive_guarded, broker_restart_resubscribe_dedup.

See run_metrics.csv for per-class latency/waiting/deadline/loss and publisher_timing.csv for replay drift. Raw traces, publisher ACK timing, receipts, completions, receiver lifecycle logs and source hashes are retained. Reconnect retries are deliberate application publishes after resubscription, not forced MQTT retransmissions or offline delivery tests.
